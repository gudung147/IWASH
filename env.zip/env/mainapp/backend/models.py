from django.db import models
# Create your models here.

# DATA INFOMATION USERS
class Users(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField(max_length=100)
    lineid = models.CharField(max_length=50, blank=True, null=True)
    phone = models.CharField(max_length=20)

    class Meta:
        verbose_name_plural = 'Users'

    def __str__(self):
        return self.name

# DATA CARS_BRAND
class Cars_Brand(models.Model):
    brand_name = models.CharField(max_length=200)

    class Meta:
        verbose_name_plural = 'Cars_Brand'

    def __str__(self):
        return self.brand_name

# DATA CARS_MODEL
class Cars_Model(models.Model):
    cars_brand = models.ForeignKey(Cars_Brand, on_delete=models.CASCADE)
    model_name = models.CharField(max_length=200)

    class Meta:
        verbose_name_plural = 'Cars_Model'

    def __str__(self):
        return self.model_name

# DATA INFOMATION CARS
class Cars(models.Model):
    users = models.ForeignKey(Users, on_delete=models.CASCADE)
    cars_brand = models.ForeignKey(Cars_Brand, on_delete=models.CASCADE)
    cars_model = models.ForeignKey(Cars_Model, on_delete=models.CASCADE)
    car_code = models.CharField(max_length=50)

    class Meta:
        verbose_name_plural = 'Cars'

    def __str__(self):
        return self.car_code


# DATA SERVICE
class Service(models.Model):
    name_service = models.CharField(max_length=100)

    class Meta:
        verbose_name_plural = 'Service'

    def __str__(self):
        return self.name_service


# SIZE
class Size(models.Model):
    size = models.CharField(max_length=50)

    class Meta:
        verbose_name_plural = 'Size'
    
    def __str__(self):
        return self.size

# SERVICE DETAIL
class Service_Detail(models.Model):
    service = models.ForeignKey(Service, on_delete=models.CASCADE)
    size = models.ForeignKey(Size, on_delete=models.CASCADE)
    price = models.CharField(max_length=50)
    nameservice = models.CharField(max_length=200)

    class Meta:
        verbose_name_plural = 'Service_Detail'
    
    def __str__(self):
        return self.nameservice

# STATUS
class Status(models.Model):
    status = models.CharField(max_length=50)

    class Meta:
        verbose_name_plural = 'Status'

    def __str__(self):
        return self.status

# ORDER
class Order(models.Model):
    name = models.CharField(max_length=200)
    owner = models.ForeignKey(Cars, on_delete=models.CASCADE)
    serviceord = models.ForeignKey(Service_Detail, on_delete=models.CASCADE)
    status = models.ForeignKey(Status, on_delete=models.CASCADE)
    price = models.CharField(max_length=10)
    note = models.CharField(max_length=200, blank=True, null=True)
    date = models.DateField(auto_now_add=True, blank=True, null=True)

    class Meta:
        verbose_name_plural = 'Order'
    
    def __str__(self):
        return self.name

# ORDER DETAIL
class Order_Detail(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    note = models.CharField(max_length=200)

    class Meta:
        verbose_name_plural = 'Order_Detail'
    
    def __str__(self):
        return self.note

# ROW_DB_TB
class tb_row(models.Model):
    name = models.CharField(max_length=100)
    m = models.CharField(max_length=10)
    l = models.CharField(max_length=10)
    xl = models.CharField(max_length=10)
    xxl = models.CharField(max_length=10)

    class Meta:
        verbose_name_plural = 'tb_row'

    def __str__(self):
        return self.name
