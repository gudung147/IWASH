from django.contrib import admin

# Customer & Vehicles
from .models import Users, Cars, Cars_Brand, Cars_Model

# Service & Order
from .models import Service, Order, Order_Detail, Size, Service_Detail, Status, tb_row
# Register your models here.

admin.site.register(Users)
admin.site.register(Cars)
admin.site.register(Cars_Brand)
admin.site.register(Cars_Model)
admin.site.register(Service)
admin.site.register(Order)
admin.site.register(Order_Detail)
admin.site.register(Size)
admin.site.register(Service_Detail)
admin.site.register(Status)
admin.site.register(tb_row)