from django.db import models
import uuid

class ProductCodeField(models.CharField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault('max_length', 4)
        kwargs.setdefault('editable', False)
        super().__init__(*args, **kwargs)

    def pre_save(self, model_instance, add):
        if not getattr(model_instance, self.attname):
            setattr(model_instance, self.attname, str(uuid.uuid4().hex)[:self.max_length])
        return getattr(model_instance, self.attname)